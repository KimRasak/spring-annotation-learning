package cn.sysu.spring.controller;

import cn.sysu.spring.Result.ResultBean;
import cn.sysu.spring.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/product")
public class MyController {

    @Autowired
    public ProductService productService;

    @GetMapping("/hello")
    public String hello() {
        return "hello";
    }

    @GetMapping("/find")
    public ResultBean findProduct(@NotNull int id) {
        return ResultBean.success(productService.findById(id));
    }

    @PostMapping("/buy")
    public ResultBean buyProduct(@NotNull int id) {
        return ResultBean.success(productService.buy(id));
    }

}
