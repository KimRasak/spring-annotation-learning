package cn.sysu.spring.service;

import cn.sysu.spring.entity.Product;
import cn.sysu.spring.mapper.ProductMapper;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

@Service
public class ProductService {

    @Autowired
    ProductMapper productMapper;

    public Product findById(int id) {
        return productMapper.findById(id);
    }

    @Transactional(rollbackFor = RuntimeException.class)
    public synchronized int buy(int id) {
        Product product = findById(id);
        System.out.println("buy " + id + " " + (product.getNum() - 1));
        return productMapper.updateNum(id, product.getNum() - 1);
    }
}
