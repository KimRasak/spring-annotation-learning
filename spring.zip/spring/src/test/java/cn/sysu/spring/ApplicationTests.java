package cn.sysu.spring;

import cn.sysu.spring.mapper.ProductMapper;
import cn.sysu.spring.service.ProductService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ApplicationTests {

	@Autowired
	private MockMvc mvc;

	@Autowired
	private ProductService productService;

	@Autowired
	private ProductMapper productMapper;

	private int TEST_NUM = 100;

	@Test
	public void testSelect() {
		for (int i = 0; i < 3; i++)
			productMapper.findById(1);
	}

	// @Test
	public void contextLoads() throws InterruptedException {
		ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(30);
		CountDownLatch latch = new CountDownLatch(TEST_NUM);
		for (int i = 0; i < TEST_NUM; i++) {
			executor.submit(() -> {
				productService.buy(1);
				latch.countDown();
			});
		};
		latch.await();
		executor.shutdown();
	}

}
